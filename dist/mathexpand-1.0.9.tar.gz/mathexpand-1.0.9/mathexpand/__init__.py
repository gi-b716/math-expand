from mathexpand.digits import *

__all__ = ['take_digits']