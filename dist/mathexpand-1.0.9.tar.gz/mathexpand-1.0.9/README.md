# math-expand Package
这个包是对Python原生的Math包进行的拓展，目前提供的方法如下：

- digits
    - take_digits(number) → list    去一个数的每一位